import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export default function GetData() {
  const navigate = useNavigate();

  const storedData = localStorage.getItem("userData");
  const data = storedData ? JSON.parse(storedData) : [];

  const deleteHandler = (id) => {
    const confirmData = window.confirm("are you want to delete?");

    if (confirmData) {
      // const item = JSON.parse(localStorage.getItem("userData"));
      const newItem = data.filter((curEl) => curEl.u_id !== id);
      localStorage.setItem("userData", JSON.stringify(newItem));
      navigate("/");
    }
  };

  return (
    <div className=" user-data ">
      <h1 className="text-center fs-3 fw-bold mt-5">User Details</h1>
      {data.length > 0 ? (
        <>
         
          <table border="1" className="user-table mt-5">
            <thead className="text-center">
              <tr>
                <td>Name</td>
                <td>Email</td>
                <td>Date</td>
                <td>Action</td>
              </tr>
            </thead>
            <tbody className="text-center">
              {data.map((item) => {
                return (
                  <>
                    <tr key={item.u_id}>
                      <td>{item.name}</td>
                      <td>{item.email}</td>
                      <td>{item.date}</td>
                      <td>
                        <Link to={`/addData/${item.u_id}`}>
                          <i className="bi bi-pencil me-2 icon rounded-circle"></i>
                        </Link>
                      
                        <Link to={"#"} onClick={() => deleteHandler(item.u_id)}>
                          <i className="bi bi-x-circle icon rounded-circle"></i>
                        </Link>
                      </td>
                    </tr>
                  </>
                );
              })}
            </tbody>
          </table>
          <Link to="/addData" className="border-0 px-4 py-2 rounded-3 text-light fs-4 text-decoration-none float-end bg-primary mt-4 d-inline-block">add</Link>
        </>
      ) : (
        <p>
          no data found Please <Link to="/addData">add</Link> data
        </p>
      )}

      {/* <AddData></AddData> */}
      {/* <h3>No user, Please <Link to="#"> click me</Link></h3> */}
    </div>
  );
}
